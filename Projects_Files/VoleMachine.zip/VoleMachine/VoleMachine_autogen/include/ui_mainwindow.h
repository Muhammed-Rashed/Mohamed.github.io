/********************************************************************************
** Form generated from reading UI file 'mainwindow.ui'
**
** Created by: Qt User Interface Compiler version 6.8.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MAINWINDOW_H
#define UI_MAINWINDOW_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QGridLayout>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QSpacerItem>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_MainWindow
{
public:
    QWidget *centralwidget;
    QGridLayout *gridLayout_4;
    QGridLayout *gridLayout_3;
    QSpacerItem *horizontalSpacer_2;
    QGridLayout *gridLayout;
    QVBoxLayout *verticalLayout_4;
    QPushButton *pushButton;
    QLabel *label_6;
    QLineEdit *lineEdit;
    QSpacerItem *verticalSpacer;
    QVBoxLayout *verticalLayout;
    QVBoxLayout *verticalLayout_6;
    QHBoxLayout *horizontalLayout_3;
    QLabel *label;
    QSpacerItem *horizontalSpacer_3;
    QLabel *label_3;
    QLabel *label_4;
    QHBoxLayout *horizontalLayout;
    QPushButton *pushButton_2;
    QLabel *program_counter;
    QLabel *instruction_register;
    QVBoxLayout *verticalLayout_3;
    QHBoxLayout *horizontalLayout_5;
    QLabel *label_5;
    QPushButton *pushButton_7;
    QHBoxLayout *horizontalLayout_2;
    QHBoxLayout *horizontalLayout_9;
    QLabel *label_2;
    QPushButton *pushButton_3;
    QPushButton *pushButton_4;
    QPushButton *pushButton_5;
    QSpacerItem *horizontalSpacer;
    QVBoxLayout *verticalLayout_2;
    QHBoxLayout *horizontalLayout_6;
    QLabel *label_7;
    QLabel *label_8;
    QHBoxLayout *horizontalLayout_4;
    QLineEdit *memory_address;
    QLineEdit *cell_value;
    QPushButton *pushButton_8;
    QHBoxLayout *horizontalLayout_10;
    QSpacerItem *horizontalSpacer_4;
    QPushButton *pushButton_6;
    QStatusBar *statusbar;

    void setupUi(QMainWindow *MainWindow)
    {
        if (MainWindow->objectName().isEmpty())
            MainWindow->setObjectName("MainWindow");
        MainWindow->resize(1200, 600);
        centralwidget = new QWidget(MainWindow);
        centralwidget->setObjectName("centralwidget");
        gridLayout_4 = new QGridLayout(centralwidget);
        gridLayout_4->setObjectName("gridLayout_4");
        gridLayout_3 = new QGridLayout();
        gridLayout_3->setObjectName("gridLayout_3");
        horizontalSpacer_2 = new QSpacerItem(40, 20, QSizePolicy::Policy::Maximum, QSizePolicy::Policy::Minimum);

        gridLayout_3->addItem(horizontalSpacer_2, 3, 1, 1, 1);

        gridLayout = new QGridLayout();
        gridLayout->setObjectName("gridLayout");

        gridLayout_3->addLayout(gridLayout, 3, 2, 1, 1);

        verticalLayout_4 = new QVBoxLayout();
        verticalLayout_4->setObjectName("verticalLayout_4");
        pushButton = new QPushButton(centralwidget);
        pushButton->setObjectName("pushButton");
        pushButton->setMaximumSize(QSize(120, 16777215));

        verticalLayout_4->addWidget(pushButton);

        label_6 = new QLabel(centralwidget);
        label_6->setObjectName("label_6");
        label_6->setMaximumSize(QSize(100, 30));
        label_6->setStyleSheet(QString::fromUtf8("color: rgb(255, 255, 255);"));

        verticalLayout_4->addWidget(label_6);

        lineEdit = new QLineEdit(centralwidget);
        lineEdit->setObjectName("lineEdit");
        lineEdit->setMaximumSize(QSize(100, 16777215));
        lineEdit->setStyleSheet(QString::fromUtf8("color: rgb(255, 255, 255);"));
        lineEdit->setEchoMode(QLineEdit::EchoMode::Normal);
        lineEdit->setAlignment(Qt::AlignmentFlag::AlignCenter);

        verticalLayout_4->addWidget(lineEdit);

        verticalSpacer = new QSpacerItem(20, 40, QSizePolicy::Policy::Minimum, QSizePolicy::Policy::Maximum);

        verticalLayout_4->addItem(verticalSpacer);


        gridLayout_3->addLayout(verticalLayout_4, 0, 0, 1, 1);

        verticalLayout = new QVBoxLayout();
        verticalLayout->setObjectName("verticalLayout");

        gridLayout_3->addLayout(verticalLayout, 3, 0, 1, 1);

        verticalLayout_6 = new QVBoxLayout();
        verticalLayout_6->setObjectName("verticalLayout_6");
        horizontalLayout_3 = new QHBoxLayout();
        horizontalLayout_3->setObjectName("horizontalLayout_3");
        label = new QLabel(centralwidget);
        label->setObjectName("label");
        label->setMaximumSize(QSize(50, 25));
        label->setStyleSheet(QString::fromUtf8("color: rgb(255, 255, 255);"));

        horizontalLayout_3->addWidget(label);

        horizontalSpacer_3 = new QSpacerItem(60, 20, QSizePolicy::Policy::Maximum, QSizePolicy::Policy::Minimum);

        horizontalLayout_3->addItem(horizontalSpacer_3);

        label_3 = new QLabel(centralwidget);
        label_3->setObjectName("label_3");
        label_3->setStyleSheet(QString::fromUtf8("color: rgb(255, 255, 255);"));

        horizontalLayout_3->addWidget(label_3);

        label_4 = new QLabel(centralwidget);
        label_4->setObjectName("label_4");
        label_4->setStyleSheet(QString::fromUtf8("color: rgb(255, 255, 255);"));

        horizontalLayout_3->addWidget(label_4);


        verticalLayout_6->addLayout(horizontalLayout_3);

        horizontalLayout = new QHBoxLayout();
        horizontalLayout->setObjectName("horizontalLayout");
        pushButton_2 = new QPushButton(centralwidget);
        pushButton_2->setObjectName("pushButton_2");
        pushButton_2->setMaximumSize(QSize(120, 16777215));

        horizontalLayout->addWidget(pushButton_2);

        program_counter = new QLabel(centralwidget);
        program_counter->setObjectName("program_counter");
        program_counter->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 255, 255);\n"
"color:rgb(0,0,0);"));
        program_counter->setAlignment(Qt::AlignmentFlag::AlignCenter);

        horizontalLayout->addWidget(program_counter);

        instruction_register = new QLabel(centralwidget);
        instruction_register->setObjectName("instruction_register");
        instruction_register->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 255, 255);\n"
"color:rgb(0,0,0);\n"
""));
        instruction_register->setAlignment(Qt::AlignmentFlag::AlignCenter);

        horizontalLayout->addWidget(instruction_register);


        verticalLayout_6->addLayout(horizontalLayout);


        gridLayout_3->addLayout(verticalLayout_6, 2, 0, 1, 1);

        verticalLayout_3 = new QVBoxLayout();
        verticalLayout_3->setObjectName("verticalLayout_3");
        horizontalLayout_5 = new QHBoxLayout();
        horizontalLayout_5->setObjectName("horizontalLayout_5");
        label_5 = new QLabel(centralwidget);
        label_5->setObjectName("label_5");
        label_5->setMaximumSize(QSize(16777215, 40));
        label_5->setStyleSheet(QString::fromUtf8("color: rgb(255, 255, 255);"));

        horizontalLayout_5->addWidget(label_5);

        pushButton_7 = new QPushButton(centralwidget);
        pushButton_7->setObjectName("pushButton_7");
        pushButton_7->setMaximumSize(QSize(200, 16777215));

        horizontalLayout_5->addWidget(pushButton_7);


        verticalLayout_3->addLayout(horizontalLayout_5);


        gridLayout_3->addLayout(verticalLayout_3, 0, 2, 1, 1);

        horizontalLayout_2 = new QHBoxLayout();
        horizontalLayout_2->setObjectName("horizontalLayout_2");
        horizontalLayout_9 = new QHBoxLayout();
        horizontalLayout_9->setObjectName("horizontalLayout_9");
        horizontalLayout_9->setContentsMargins(-1, 50, -1, -1);
        label_2 = new QLabel(centralwidget);
        label_2->setObjectName("label_2");
        label_2->setMaximumSize(QSize(50, 50));
        label_2->setStyleSheet(QString::fromUtf8("color: rgb(255, 255, 255);"));

        horizontalLayout_9->addWidget(label_2);

        pushButton_3 = new QPushButton(centralwidget);
        pushButton_3->setObjectName("pushButton_3");
        pushButton_3->setMaximumSize(QSize(100, 16777215));

        horizontalLayout_9->addWidget(pushButton_3);

        pushButton_4 = new QPushButton(centralwidget);
        pushButton_4->setObjectName("pushButton_4");
        pushButton_4->setMaximumSize(QSize(120, 16777215));

        horizontalLayout_9->addWidget(pushButton_4);

        pushButton_5 = new QPushButton(centralwidget);
        pushButton_5->setObjectName("pushButton_5");
        pushButton_5->setMaximumSize(QSize(100, 16777215));

        horizontalLayout_9->addWidget(pushButton_5);

        horizontalSpacer = new QSpacerItem(40, 20, QSizePolicy::Policy::Maximum, QSizePolicy::Policy::Minimum);

        horizontalLayout_9->addItem(horizontalSpacer);


        horizontalLayout_2->addLayout(horizontalLayout_9);

        verticalLayout_2 = new QVBoxLayout();
        verticalLayout_2->setObjectName("verticalLayout_2");
        horizontalLayout_6 = new QHBoxLayout();
        horizontalLayout_6->setObjectName("horizontalLayout_6");
        label_7 = new QLabel(centralwidget);
        label_7->setObjectName("label_7");
        label_7->setStyleSheet(QString::fromUtf8("color: rgb(255, 255, 255);"));
        label_7->setAlignment(Qt::AlignmentFlag::AlignCenter);

        horizontalLayout_6->addWidget(label_7);

        label_8 = new QLabel(centralwidget);
        label_8->setObjectName("label_8");
        label_8->setStyleSheet(QString::fromUtf8("color: rgb(255, 255, 255);"));
        label_8->setAlignment(Qt::AlignmentFlag::AlignCenter);

        horizontalLayout_6->addWidget(label_8);


        verticalLayout_2->addLayout(horizontalLayout_6);

        horizontalLayout_4 = new QHBoxLayout();
        horizontalLayout_4->setObjectName("horizontalLayout_4");
        memory_address = new QLineEdit(centralwidget);
        memory_address->setObjectName("memory_address");
        memory_address->setStyleSheet(QString::fromUtf8("color: rgb(255, 255, 255);"));
        memory_address->setAlignment(Qt::AlignmentFlag::AlignCenter);

        horizontalLayout_4->addWidget(memory_address);

        cell_value = new QLineEdit(centralwidget);
        cell_value->setObjectName("cell_value");
        cell_value->setStyleSheet(QString::fromUtf8("color: rgb(255, 255, 255);"));
        cell_value->setCursorPosition(4);
        cell_value->setAlignment(Qt::AlignmentFlag::AlignCenter);

        horizontalLayout_4->addWidget(cell_value);


        verticalLayout_2->addLayout(horizontalLayout_4);

        pushButton_8 = new QPushButton(centralwidget);
        pushButton_8->setObjectName("pushButton_8");

        verticalLayout_2->addWidget(pushButton_8);


        horizontalLayout_2->addLayout(verticalLayout_2);

        horizontalLayout_10 = new QHBoxLayout();
        horizontalLayout_10->setObjectName("horizontalLayout_10");
        horizontalLayout_10->setContentsMargins(-1, 50, -1, -1);
        horizontalSpacer_4 = new QSpacerItem(40, 20, QSizePolicy::Policy::Maximum, QSizePolicy::Policy::Minimum);

        horizontalLayout_10->addItem(horizontalSpacer_4);

        pushButton_6 = new QPushButton(centralwidget);
        pushButton_6->setObjectName("pushButton_6");
        pushButton_6->setMaximumSize(QSize(120, 16777215));

        horizontalLayout_10->addWidget(pushButton_6);


        horizontalLayout_2->addLayout(horizontalLayout_10);


        gridLayout_3->addLayout(horizontalLayout_2, 2, 2, 1, 1);

        gridLayout_3->setColumnStretch(0, 1);

        gridLayout_4->addLayout(gridLayout_3, 0, 0, 1, 1);

        MainWindow->setCentralWidget(centralwidget);
        statusbar = new QStatusBar(MainWindow);
        statusbar->setObjectName("statusbar");
        MainWindow->setStatusBar(statusbar);

        retranslateUi(MainWindow);

        QMetaObject::connectSlotsByName(MainWindow);
    } // setupUi

    void retranslateUi(QMainWindow *MainWindow)
    {
        MainWindow->setWindowTitle(QCoreApplication::translate("MainWindow", "MainWindow", nullptr));
        pushButton->setText(QCoreApplication::translate("MainWindow", "Load Program", nullptr));
        label_6->setText(QCoreApplication::translate("MainWindow", "Starting Address", nullptr));
        lineEdit->setText(QCoreApplication::translate("MainWindow", "0x10", nullptr));
        label->setText(QCoreApplication::translate("MainWindow", "Registers", nullptr));
        label_3->setText(QCoreApplication::translate("MainWindow", "Program counter", nullptr));
        label_4->setText(QCoreApplication::translate("MainWindow", "Instruction register", nullptr));
        pushButton_2->setText(QCoreApplication::translate("MainWindow", "Clear Registers", nullptr));
        program_counter->setText(QString());
        instruction_register->setText(QString());
        label_5->setText(QCoreApplication::translate("MainWindow", "Program Output", nullptr));
        pushButton_7->setText(QCoreApplication::translate("MainWindow", "Clear Screen", nullptr));
        label_2->setText(QCoreApplication::translate("MainWindow", "Memory", nullptr));
        pushButton_3->setText(QCoreApplication::translate("MainWindow", "One Step", nullptr));
        pushButton_4->setText(QCoreApplication::translate("MainWindow", "Multiple Step", nullptr));
        pushButton_5->setText(QCoreApplication::translate("MainWindow", "Until HALT", nullptr));
        label_7->setText(QCoreApplication::translate("MainWindow", "Address", nullptr));
        label_8->setText(QCoreApplication::translate("MainWindow", "Value", nullptr));
        memory_address->setInputMask(QString());
        memory_address->setText(QCoreApplication::translate("MainWindow", "0x00", nullptr));
        cell_value->setInputMask(QString());
        cell_value->setText(QCoreApplication::translate("MainWindow", "0x00", nullptr));
        pushButton_8->setText(QCoreApplication::translate("MainWindow", "Add cell to memory", nullptr));
        pushButton_6->setText(QCoreApplication::translate("MainWindow", "Clear Memory", nullptr));
    } // retranslateUi

};

namespace Ui {
    class MainWindow: public Ui_MainWindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MAINWINDOW_H
